#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void sighandler(int);

int main() {
    signal(SIGINT, sighandler);
    int size = sizeof(all_tests)/sizeof(test_data);
    printf("Running %d tests:\n", size);
    printf("=====================\n\n");
    int retorno;
    pid_t filho[size];
    int status[size];
    float tempos[size];
    int returno[size];
    int pass_count = 0;
    int pappy = getpid();

    for (int i = 0; i < size; i++) {

      filho[i] = fork();
      if (filho[i] == 0) {
        alarm(10);
      // if (getpid() - pappy == i + 1) {
        returno[i] = all_tests[i].function();
        // printf("%d\n", returno);

        return returno[i];
      }
    }

    // if (getpid() - pappy == 0) {
      //sleep(1);
    //printf("%d", returno[2]);
    for (int i = 0; i < size; i++) {

      // if (WTERMSIG(status[i]) != 0) {
      //wait(&status[i]);
      waitpid(filho[i], &status[i], 0);
    }

    printf("\n\n=====================\n");

    for (int i = 0; i < size; i++) {

      //printf("%d\n", WEXITSTATUS(status[i]));
      if (WIFEXITED(status[i]) == 1){//WIFEXITED(status[i])) {
        if (WEXITSTATUS(status[i]) == 0){//WEXITSTATUS(status[i]) == 0) {
            printf("test%d [PASS]\n", i + 1);
            pass_count++;
        } else {
            printf("test%d [FALHOU]\n", i + 1);
        }

        // printf("Estorou o tempo, saindo do teste %d...\n", i + 1);

        //kill(pappy + i + 1, 2);
      } else {
        if (WTERMSIG(status[i]) == 14) {
          printf("test%d [ERRO]: O tempo para esse teste estorou\n", i + 1);
        } else if (WTERMSIG(status[i]) == 8) {
          printf("test%d [ERRO]: Divisao por 0\n", i + 1);
        } else if (WTERMSIG(status[i]) == 11) {
          printf("test%d [ERRO]: Falha de segmentacao\n", i + 1);
        }
      }
      // else if (WIFSIGNALED(status[i])) {
      //   printf("test%d foi morto pelo sinal %d\n", i + 1, WIFSIGNALED(status[i]));
      // }
      //waitpid(filho[i], &status[i], 0);
    }


    printf("\n=====================\n\n");
    printf("%d/%d tests passed\n", pass_count, size);
    // }



    return 0;
}

void sighandler(int signum) {
   printf("Recebeu sinal %d, saindo...\n", signum);
   exit(signum);
}
