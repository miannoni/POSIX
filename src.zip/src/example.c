#include "mintest/macros.h"

int test1() {
    //int var;
    //var = test_printf("Hello! %d %f\n", 3, 3.14);
    int matriz[500][500];//[500][500];
    int i = 0;
    while (matriz[499][499] < 500) {//[499][499] < 500) {
      for (int j = 0; j < 50; j++) {
        matriz[i%500][(i/500)%500] += matriz[(i + j)%500][((i + j)/500)%500] - matriz[(i + j)%500][(i/500)%500] + matriz[i%500][((i + j)/500)%500];
      }
       //matriz[i%500][(i/500)%500] += matriz[(i + 35)%500][((i + 100)/500)%500] - matriz[(i + 42)%500][(i/500)%500] + matriz[i%500][(i/500)%500];//[(i/(500*500))%500][(i/(500*500*500))%500] += 1;
       i++;
    }


    return 0;
}

int test2() {

    //int var;
    //var = test_assert(1 == 0, "This always fails!");
    test_assert(1 == 1, "This always suc sess!");
    test_assert(1 == 0, "This always fails!");

    return 0;
}

int test3() {
    for (int i = 0; i < 500; i++) {
      printf("printei %d!\n", i);
    }
    // test_printf("<-- Name of the function before the printf!\n");
    //int var;
    //test_assert(1 == 1, "This always succeeds");
    return 0;
}

int test4() {
   //char *stringe;
   //stringe = "banana";
   //*(stringe + 1) = 'k';
   // test_printf("Comecando teste\n");
   // int k = 0;
   // while (1) {
     //printf("%d\n", k);
     // k++;
   // }
   // test_printf("Terminou!\n");

   int numero[1];

   numero[5] = 1;

   return 0;

   //return 5/0;
}



int test5() {
    //test_printf("<-- Name of the function before the printf!\n");
    while (1) {

    }

    // sleep(5);
    test_printf("Terminou!\n");
    //test_assert(1 == 0, "This always fails!");
    return 0;
}

int test6() {

   int numero;

   numero = 1/0;

   return 0;

}

int test7() {
   test_assert(1 == 0, "Fail!");

   return 0;

}

int test8() {

  sleep(3);
   test_assert(1 == 1, "Sucesso!");

   return 0;

}

int test9() {

  sleep(6);
   test_assert(1 == 0, "Fail!");

   return 0;

}

int test10() {

  sleep(8);
   test_assert(1 == 1, "Sucesso!");

   return 0;

}

test_list = { TEST(test1) , TEST(test2), TEST(test3) , TEST(test4) , TEST(test5) , TEST(test6) , TEST(test7) , TEST(test8) , TEST(test9) , TEST(test10) };

#include "mintest/runner.h"
